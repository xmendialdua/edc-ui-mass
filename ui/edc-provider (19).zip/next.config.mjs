/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Configuración para entornos de producción
  output: 'standalone', // Genera una salida optimizada para Docker
  experimental: {
    // Desactivamos algunas características experimentales que podrían causar problemas
    webpackBuildWorker: false,
    parallelServerBuildTraces: false,
    parallelServerCompiles: false,
  },
}

export default nextConfig
